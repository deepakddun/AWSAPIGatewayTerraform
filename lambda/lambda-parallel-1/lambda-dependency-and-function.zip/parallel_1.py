def handler(event, context):
    print("Inside parallel 1 lambda function 1")

    return "Inside parallel 1 lambda function 1"
