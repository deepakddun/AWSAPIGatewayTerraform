def handler(event, context):
    print("Inside parallel 2 lambda function 2")

    return "Inside parallel 2 lambda function 2"
